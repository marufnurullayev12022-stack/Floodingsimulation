# -*- coding: utf-8 -*-
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QAction
from qgis.core import QgsApplication
import os

from .flood_panel import FloodSimPanel

class Flood3DSim:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.action = None
        self.panel = None

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, 'icon.png')
        self.action = QAction(QIcon(icon_path), '3D Flood Simulation', self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        
        # Add to the new top menu "Flooding 3D"
        self.menu = '&Flooding 3D'
        self.iface.addPluginToMenu(self.menu, self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        self.iface.removePluginMenu(self.menu, self.action)
        self.iface.removeToolBarIcon(self.action)
        if self.panel:
            self.iface.removeDockWidget(self.panel)
            self.panel.server.stop()
            self.panel.deleteLater()
            self.panel = None

    def run(self):
        if not self.panel:
            self.panel = FloodSimPanel(self.iface, self.iface.mainWindow())
            self.iface.addDockWidget(Qt.BottomDockWidgetArea, self.panel)
        self.panel.show()
